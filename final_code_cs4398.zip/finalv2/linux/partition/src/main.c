#include <stdio.h>
#include <sys/types.h>
#include <fcntl.h>

#include <string.h>

extern void partitionInfo(int fd);

int PartitionNum = 0;

void main(int argc, char** argv) {
        short arg2Len;
	int fd;

        arg2Len = strlen(argv[1]);
#ifdef DEBUG
        printf("main: arglen =  %d\n", arg2Len );
#endif

        if ( arg2Len != 8 ) {
           fprintf(stderr, "(1)USAGE: %s /dev/sdx\n", argv[0]);
           fprintf(stderr, "OR \n %s /dev/sdx [#|all]\n", argv[0]);
           return;
        }
        if(argc == 2) {
#ifdef DEBUG
           printf("main: arg2 = %s\n", argv[1] );
           printf("main: arg2 part = %x\n", argv[1][8] );
#endif
           if ( argv[1][8] <= '0' || argv[1][8] > '9' ) {
              PartitionNum = 0;   // default is all
           }
           else {
              fprintf(stderr, "(2)USAGE: %s /dev/sdx\n", argv[0]);
              fprintf(stderr, "OR \n %s /dev/sdx [#|all]\n", argv[0]);
              return;
           }
        }
        else if(argc == 3) {
#ifdef DEBUG
           printf("main: arg2 = %s\n", argv[1] );
           printf("main: arg2 part = %x\n", argv[1][8] );
           printf("main: arg3 = %s\n", argv[2] );
#endif
           /* arg2 should be /dev/sdx  */
           if ( argv[1][8] >= '0' && argv[1][8] <= '9' ) {
              fprintf(stderr, "(3)USAGE: %s /dev/sdx#\n", argv[0]);
              fprintf(stderr, "OR \n %s /dev/sdx [#|all]\n", argv[0]);
              return(0);
           }
	   else if ( strcmp(argv[2], "all" ) == 0) {
              PartitionNum = 0;   // all partitions
           }
           else if ( argv[2][0] > '0' || argv[2][0] <= '9' ) {
              PartitionNum = argv[2][0] - '0';
#ifdef DEBUG
              printf("main: partitionnum = %d\n", PartitionNum );
#endif
           }
           else {
              fprintf(stderr, "(4)USAGE: %s /dev/sdx#\n", argv[0]);
              fprintf(stderr, "OR \n %s /dev/sdx [#|all]\n", argv[0]);
              return(0);
           }
        }
        else {
              fprintf(stderr, "(5)USAGE: %s /dev/sdx#\n", argv[0]);
              fprintf(stderr, "OR \n %s /dev/sdx [#|all]\n", argv[0]);
              return(0);
        }


	fd = open(argv[1], O_RDONLY);
	if ( fd <= 0 )
	{
		fprintf(stderr, "device not opened %s\n", argv[1] );
		return;
	}

        partitionInfo(fd);

	close(fd);
}
