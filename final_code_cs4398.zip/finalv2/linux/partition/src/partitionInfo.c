#include <stdio.h>
#include <stdbool.h>
#include "partGPT.h"


#define MAX_NUM_OF_PARTITIONS 4
/*
extern void mbrCreateObj( int );
extern unsigned int getPartType( int );
extern unsigned long getPartLba( int );
extern unsigned long getPartSize( int );
*/


extern bool mbrObjCreated;
extern PartitionNum;


void partitionInfo(int fd) 
{
   unsigned int partType;
   unsigned long partLba;
   unsigned long partSize;

   mbrCreateObj( fd );
   if ( mbrObjCreated == false ) {
      fprintf( stderr, "ntfs: unable to crete MBR \n" );
      return;
   }

   partType = getPartType( 1 );
   if ( partType == 0xee ) {
      GPT_header GptSector;
      GPT_Entry gptentry;
      unsigned char *b;
      int retVal;

      b = ( unsigned char *)&GptSector;
      retVal = read(fd, b, 512);
      if ( retVal < 0 ) {
         fprintf(stderr, "part: unable to read disk, retVal = %d\n", retVal );
         return;
      }



      b = ( unsigned char *)&gptentry;
      retVal = read(fd, b, 512);
      if ( retVal < 0 ) {
         fprintf(stderr, "part: unable to read disk, retVal = %d\n", retVal );
         return;
      }
      printf("partiton info: 0x%x(%d) \n", gptentry.lba_start, gptentry.lba_start);
      printf("partiton info: 0x%x(%u) \n", gptentry.lba_end, gptentry.lba_end);

      partLba = getPartLba( PartitionNum );
      printf(" \tPartiton Start LBA: %x\n", partLba );
   }
   else if ( PartitionNum == 0 ) {
      /* all partitions on disk */
      int i;
      for ( i = 1; i <= MAX_NUM_OF_PARTITIONS; i++ ) {
         partType = getPartType( i );
         partLba = getPartLba( i );
         partSize = getPartSize( i );
         printf(" Partition number %d: \n", i );
         printf(" \tPartiton type: %x\n", partType );
         printf(" \tPartiton Start LBA: %x\n", partLba );
         printf(" \tPartiton Size: 0x%x(%d)\n", partSize, partSize );
      }
   }
   else {
      partType = getPartType( PartitionNum );
      partLba = getPartLba( PartitionNum );
      partSize = getPartSize( PartitionNum );
      printf(" Partition number %d: \n", PartitionNum );
      printf(" \tPartiton type: %x\n", partType );
      printf(" \tPartiton Start LBA: %x\n", partLba );
      printf(" \tPartiton Size: 0x%x(%d)\n", partSize, partSize );
   }


}
