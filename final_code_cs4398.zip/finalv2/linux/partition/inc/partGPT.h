#ifndef _GPT_PART
#define _GPT_PART

#include <linux/types.h>

#define GPT_PART_NAME_LEN   (72 / sizeof(uint16_t))

/* GPT header */
typedef struct gpt_header {
	__u64            signature; /* header identification */
	__u32            revision; /* header version */
	__u32            size; /* in bytes */
	__u32            crc32; /* header CRC checksum */
	__u32            reserved1; /* must be 0 */
	__u64            my_lba; /* LBA of block that contains this struct (LBA 1) */
	__u64            alternative_lba; /* backup GPT header */
	__u64            first_usable_lba; /* first usable logical block for partitions */
	__u64            last_usable_lba; /* last usable logical block for partitions */
	__u8             disk_guid[16]; /* unique disk identifier */
	__u64            partition_entry_lba; /* LBA of start of partition entries array */
	__u32            npartition_entries; /* total partition entries - normally 128 */
	__u32            sizeof_partition_entry; /* bytes for each GUID pt */
	__u32            partition_entry_array_crc32; /* partition CRC checksum */
	__u8             reserved2[512 - 92]; /* must all be 0 */
} __attribute__ ((packed)) GPT_header;


/* Globally unique identifier */
struct gpt_guid {
	__u32   time_low;
	__u16   time_mid;
	__u16   time_hi_and_version;
	__u8    clock_seq_hi;
	__u8    clock_seq_low;
	__u8    node[6];
};

typedef struct gpt_entry {
	struct gpt_guid     type; /* purpose and type of the partition */
	struct gpt_guid     partition_guid;
	__u64            lba_start;
	__u64            lba_end;
	__u64            attrs;
	__u16            name[36];
}  __attribute__ ((packed)) GPT_Entry;


#endif
