#include <iostream>

#include "NTFSReader.h"

using namespace std;

int main(int argc, char *argv[]) {
	if (argc < 2) {
		printf("\nUsage must be: ntfs /dev/sdx# or ntfs /dev/sdx# filename /dev/sdx#_2\n\n");
		printf("You are missing at least one argument.\n\n");
		printf("The first command works on all properly formatted NTFS partitions and will\n");
		printf("return error codes if for any reason the partition is not a proper NTFS partition.\n\n");
		printf("The second command retrieves a deleted file from an NTFS partition\n");
		printf("and writes them to a second partition on the drive. NTFS checking still applies.\n");
		printf("If no deleted files are found via the second command, we will return and inform you.\n");
		return 0;
	} else if (argc == 2) {
		NTFSReader disk = NTFSReader(argv[argc-1]);
		disk.listFileNames();
		//disk.listDeletedFiles();
	} else if (argc == 3) {
		printf("\nUsage must be: ntfs /dev/sdx# or ntfs /dev/sdx# filename /dev/sdx#_2\n\n");
		printf("You have either included one too many arguments, or are missing at least one.\n\n");
		printf("The first command works on all properly formatted NTFS partitions and will\n");
		printf("return error codes if for any reason the partition is not a proper NTFS partition.\n\n");
		printf("The second command retrieves a deleted file from an NTFS partition\n");
		printf("and writes them to a second partition on the drive. NTFS checking still applies.\n");
		printf("If no deleted files are found via the second command, we will return and inform you.\n");
	} else if (argc == 4) {
		NTFSReader disk = NTFSReader(argv[argc-3]);
		//disk.listFileNames();
		disk.retrieveDeletedFile(argv[argc-2], argv[argc-1]);
		//printf("\n\ncode is not here yet");
	} else {
		printf("\nUsage must be: ntfs /dev/sdx# or ntfs /dev/sdx# filename /dev/sdx#_2\n\n");
		printf("You have included one too many arguments.\n\n");
		printf("The first command works on all properly formatted NTFS partitions and will\n");
		printf("return error codes if for any reason the partition is not a proper NTFS partition.\n\n");
		printf("The second command retrieves a deleted file from an NTFS partition\n");
		printf("and writes them to a second partition on the drive. NTFS checking still applies.\n");
		printf("If no deleted files are found via the second command, we will return and inform you.\n");
	}
	return 0;
}
