#include "vbr.h"
#include <unistd.h>
#include "bootrecdefs.h"
#include <endian.h>
#include "MFTentry.h"
#include <stdbool.h>
#include <attribute.h>
#include <stdlib.h>
#include <string.h>


#define DEBUG 1
extern void mbrCreateObj( int );
extern void vbrCreateObj( int );
extern unsigned long long getMFTAddr();
extern void prtMbr();
extern void prtVbr();

extern struct disk_ntfs_vbr vbrObj;
extern unsigned long vbraddr;
extern bool vbrObjCreated;
extern bool mbrObjCreated;


bool verifyFILE( unsigned char *mftMagic ) {


   if ( ( mftMagic[0] == 0x46 ) && ( mftMagic[1] == 0x49 ) && ( mftMagic[2] == 0x4c ) && ( mftMagic[3] == 0x45 ) ) {
      return (true);
   }
   else {
      return (false);
   }

}

struct MFTentry *getMFTentry( int fd ) {
   unsigned long long entryAddr;
   unsigned long curLoc;
   unsigned char b[SIZE_OF_CLUSTER];
   struct MFTentry *mft;
   int retVal;

   entryAddr = getMFTAddr( fd );

   curLoc = lseek( fd, entryAddr, SEEK_SET );

   retVal = read(fd, b, SIZE_OF_CLUSTER );
   if ( retVal < 0 ) {
      fprintf(stderr, "unable to read disk, retVal = %d\n", retVal );
      return(NULL);
   }

   mft = (struct MFTentry *)b ;

   return ( mft );

}

unsigned char *getDataAttributeAdd(  struct MFTentry *mftentry ) {
   unsigned short attribOffset;
   AttributeHeader *attribHdr;
   struct ResFname *rfn;
   unsigned char *tmp;
   unsigned int count;
   unsigned int type;

   attribOffset = le16toh(mftentry->attrOffset);
   tmp = (unsigned char *)mftentry;
    
   tmp = tmp + attribOffset;    // 1st attribute
   count = attribOffset;

   attribHdr = ( AttributeHeader *) tmp;
   type = le16toh(attribHdr->type);

   count = attribHdr->length + count;
   while ( type != ATTRIBUTE_LIST_TERMINATOR ) {

       if ( count > 0x1000 ) {
           fprintf(stderr, "getDataAttributeAdd: ERROR, NO NAME ATTRIBUTE FOUND \n" );
           return NULL;
       }

       if ( type == ATTRIB_DATA_TYPE ) {

           return tmp;

       }


       tmp = tmp + attribHdr->length;
       attribHdr = ( AttributeHeader *) tmp;
       type = le16toh(attribHdr->type);
       count = attribHdr->length + count;
   }
}


unsigned char *getNameAttributeAdd(  struct MFTentry *mftentry ) {
   unsigned short attribOffset;
   AttributeHeader *attribHdr;
   struct ResFname *rfn;
   unsigned char *tmp;
   unsigned int count;
   unsigned int type;

   attribOffset = le16toh(mftentry->attrOffset);
   tmp = (unsigned char *)mftentry;
    
   tmp = tmp + attribOffset;    // 1st attribute
   count = attribOffset;

   attribHdr = ( AttributeHeader *) tmp;
   type = le16toh(attribHdr->type);

   count = attribHdr->length + count;
   while ( type != ATTRIBUTE_LIST_TERMINATOR ) {

       if ( count > 0x1000 ) {
           fprintf(stderr, "getAttributeAdd: ERROR, NO NAME ATTRIBUTE FOUND \n" );
           return NULL;
       }

       /* Many entries will have two FILE_NAME attributes.  The second attribute has full file name.
        * The first FILE_NAME attribute has a truncated file name for back ward compatibility
        * So even after finding the FILE_NAME Attribute, we continue checking if there is a second FILE_NAME attribute
        */
       if ( type == ATTRIB_FILE_NAME_TYPE ) {
           struct ResFname *tmp1;
           tmp1 = (struct ResFname *)tmp;

           if ( rfn == NULL ) {

              rfn = (struct ResFname *)tmp;
           }
           else {
              if ( tmp1->attrHeader.length >= rfn->attrHeader.length ) {
                 rfn = tmp1;
              }
              return tmp;
           }

       }


       tmp = tmp + attribHdr->length;
       attribHdr = ( AttributeHeader *) tmp;
       type = le16toh(attribHdr->type);
       count = attribHdr->length + count;


   }


}

void prtEntryName( struct MFTentry *mftentry ) {
   unsigned char *ret;
   struct ResFname *rFname;
   int len;

   ret = getNameAttributeAdd(  mftentry );
   if ( ret == NULL ) {
      printf("prtEntryName: ERROR - ret NULL\n");
      return;
   }
   rFname = ( struct ResFnme *)ret;


   printf(" FILE NAME - ");
   len = rFname->fnameHdr.filenameLength ;
   len = len * 2;
   for ( int i = 0; i < len ; i++ ) {

       printf("%c", rFname->fnameHdr.fileName[i] );
       i++;
   }
   printf("\n");

}



void prtEntrydataRun( struct MFTentry *mftentry ) {
   unsigned char *ret;
   struct NonResData *ndata; 
   unsigned char *datarun;
   unsigned long currByteLoc = 0;
   unsigned char header;
   unsigned char offsetSize;
   unsigned char lengthSize;
   unsigned long prevOffset = 0;
   unsigned long runLength = 0;
   unsigned long clusterOffset = 0;
   unsigned long clusterNum;

   ret = getDataAttributeAdd(  mftentry );
   if ( ret == NULL ) {
      printf("prtEntryName: ERROR - ret NULL\n");
      return;
   }

   ndata = ( struct nonResData *)ret;
   if ( ndata->attrHeader.nonResidentFlag == 0x0 ) {
      return;
   }
   datarun = &ndata->data[0];

   header = datarun[currByteLoc];

   while ( header != CLUSTER_RUN_END ) {

      // get the top four bits
      offsetSize = header >> 4;
      // get the bottom four bits
      lengthSize = header & 0x0F;


      currByteLoc += CLUSTER_RUN_HEADER_SIZE;
      if ( ( offsetSize == 0 ) || ( lengthSize == 0 ) ) {
         return;
      }

      memcpy( &runLength, &datarun[currByteLoc], lengthSize );

      currByteLoc += lengthSize;;
      memcpy( &clusterOffset, &datarun[currByteLoc], offsetSize );

      clusterNum = clusterOffset + prevOffset;


      printf( "prtEntryDataRun: clusterNum = %x\n", clusterNum );
      printf( "prtEntryDataRun: runLength = %x\n", runLength );

      prevOffset += clusterOffset;
      currByteLoc += offsetSize;;

      header = datarun[currByteLoc];

   }


}


void prtMftEntry( int fd ) {
   struct MFTentry *mftentry;
   unsigned char *mftMagic;

   mftentry = getMFTentry( fd );
   if ( mftentry == NULL ) {
      fprintf( stderr, "prtMftEntry: mftentry NULL \n" );
      return;
   }

   mftMagic = mftentry->mftMagic;
   if ( verifyFILE( mftMagic ) == false ) {
      fprintf( stderr, "prtMftEntry: FILE magic failed to verify\n" );
      return;
   }
   prtEntryName( mftentry );


   prtEntrydataRun( mftentry );
}