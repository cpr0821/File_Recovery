#include <unistd.h>
#include <sys/types.h>
#include <fcntl.h>
#include <stdio.h>
#include "mbr.h"
#include "bootrecdefs.h"
#include <string.h>
#include <stdbool.h>

#define BLK_SIZE 4096


unsigned long VbrClusterLocation = 0;

DISK_mbr mbrObj;
bool mbrObjCreated = false;


void prtLBALocation( ) {
   int i;

   for ( i = 0; i < MAX_NUM_OF_PARTITIONS; i++ ) {
      printf( "LBA Begin/Starting Sector %d = %4x \n", i, mbrObj.pt[i].first_sector_lba );
   }

}


unsigned long getPartSize( int pnum ) {

#ifdef DEBUG
       printf( "getPartSize: %x\n", mbrObj.pt[pnum-1].sector_count );
#endif

       return ( mbrObj.pt[pnum-1].sector_count );
}


unsigned long getPartLba( int pnum ) {

#ifdef DEBUG
       printf( "getPartLba: %x\n", mbrObj.pt[pnum-1].first_sector_lba );
#endif

       return ( mbrObj.pt[pnum-1].first_sector_lba );
}

unsigned int getPartType( int pnum ) {
#ifdef DEBUG
       printf( "getPartType: %x\n", mbrObj.pt[pnum-1].partition_type );
#endif
       return ( mbrObj.pt[pnum-1].partition_type );
}

void prtPartitionType( ) {
   int i;

   for ( i = 0; i < MAX_NUM_OF_PARTITIONS; i++ ) {
       printf( "Partition type %i = %x \n", i, mbrObj.pt[i].partition_type );
   }

}

void prtMbr( ) {
   unsigned char *b;

   b = (char *)&mbrObj;
   for( int i = 0; i < SIZE_OF_BR; i++ )
   {
      if ( i%16 == 0 ) {
         printf( "\n" );
      }
      printf( "%2x ",b[i] );
   }
   printf( "\n" );
}


/*  consider mbr an object */
void mbrCreateObj( int fd ) {
   int retVal;
   unsigned char *b;

   b = (unsigned char *)&mbrObj;
   retVal = read(fd, b, SIZE_OF_BR);
   if ( retVal < 0 ) {
      fprintf(stderr, "mbrCreateObj: unable to read disk, retVal = %d\n", retVal );
      return;
   }
   if ( (b[MAGIC1_LOC] != MAGIC_VAL1) && (b[MAGIC2_LOC] != MAGIC_VAL2) )
   {
      fprintf(stderr, "mbrCreateObj: MBR corrupted ... \n");
      return;
   }

   mbrObjCreated = true;;
   return;

}

void mbr( int fd ) {

   mbrCreateObj( fd );
   if ( mbrObjCreated == false ) {
      fprintf( stderr, "mbr: MBR not created\n" );
      return;
   }

   prtMbr( );

   prtPartitionType( );

   prtLBALocation( );

}
