#include <sys/stat.h>
// #include <sys/ioctl.h>
#include <linux/hdreg.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <sys/types.h>
#include "test5.h"
#include <errno.h>

