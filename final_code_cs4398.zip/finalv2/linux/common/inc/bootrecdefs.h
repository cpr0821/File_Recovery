#ifndef __BOOTREC__

#define __BOOTREC__

#define SIZE_OF_SECTOR 0x200
#define SIZE_OF_CLUSTER 0x1000
#define SIZE_OF_BR 512
#define MAGIC1_LOC  510
#define MAGIC2_LOC  511

#define MAGIC_VAL1  0x55
#define MAGIC_VAL2  0xaa

#define MAX_NUM_OF_PARTITIONS   4

#endif
