#ifndef __MBR__

#define __MBR__
#include <linux/types.h>

typedef struct mbr_partition_table_entry
{
    __u8 status;
    __u8 start_chs[3];
    __u8 partition_type;
    __u8 end_chs[3];
    __u32 first_sector_lba;
    __u32 sector_count;
} MBR_partition_table_entry;


typedef struct disk_mbr
{
    __u8 code[440];
    __u32 disk_signature;
    __u16 reserved;
    MBR_partition_table_entry pt[4];
    __u8 signature[2];
} __attribute__((packed)) DISK_mbr;

#endif
